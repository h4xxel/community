-- phpMyAdmin SQL Dump
-- version 3.3.7deb3build0.10.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 21, 2011 at 12:42 PM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-1ubuntu9.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `community`
--

-- --------------------------------------------------------

--
-- Table structure for table `com_categories`
--

CREATE TABLE IF NOT EXISTS `com_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `com_categories`
--


-- --------------------------------------------------------

--
-- Table structure for table `com_forum`
--

CREATE TABLE IF NOT EXISTS `com_forum` (
  `server_id` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `description` text,
  PRIMARY KEY (`server_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `com_forum`
--

INSERT INTO `com_forum` (`server_id`, `name`, `description`) VALUES
('R68QZskkM8JPH589', 'omfg', 'best cry ever');

-- --------------------------------------------------------

--
-- Table structure for table `com_groups`
--

CREATE TABLE IF NOT EXISTS `com_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `com_groups`
--

INSERT INTO `com_groups` (`id`, `name`) VALUES
(1, 'Admin'),
(2, 'Moderator'),
(3, 'User');

-- --------------------------------------------------------

--
-- Table structure for table `com_permissions`
--

CREATE TABLE IF NOT EXISTS `com_permissions` (
  `category` int(10) unsigned NOT NULL,
  `group` int(10) unsigned NOT NULL,
  PRIMARY KEY (`category`,`group`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `com_permissions`
--


-- --------------------------------------------------------

--
-- Table structure for table `com_posts`
--

CREATE TABLE IF NOT EXISTS `com_posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `time_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `time_modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `creator` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `com_posts`
--


-- --------------------------------------------------------

--
-- Table structure for table `com_threads`
--

CREATE TABLE IF NOT EXISTS `com_threads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `description` text,
  `views` int(10) unsigned NOT NULL,
  `time_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creator` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `com_threads`
--


-- --------------------------------------------------------

--
-- Table structure for table `com_users`
--

CREATE TABLE IF NOT EXISTS `com_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(16) NOT NULL,
  `email` varchar(128) NOT NULL,
  `password` varchar(64) NOT NULL,
  `avatar` varchar(256) DEFAULT NULL,
  `signature` text,
  `location` varchar(32) DEFAULT NULL,
  `registered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_active` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `group` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `com_users`
--

INSERT INTO `com_users` (`id`, `username`, `email`, `password`, `avatar`, `signature`, `location`, `registered`, `last_active`, `group`) VALUES
(1, 'leet', 'leet@1337.org', 'b68918ef29dd7499fada16d28b0ae915b3e9f4df', NULL, '1337', 'mothership', '2011-01-21 11:58:57', '2011-01-21 00:00:00', 1);
